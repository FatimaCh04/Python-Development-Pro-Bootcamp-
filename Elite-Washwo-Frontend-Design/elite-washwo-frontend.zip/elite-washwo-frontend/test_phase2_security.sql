-- ==============================================================================
-- ELITE WASH ERP — PHASE 2 APPROVAL SECURITY TEST SUITE
-- Version: 2.6 (Hardened Test Harness: Synthetic Auth Integration & Strict Assertion Reporting)
-- TRANSACTIONAL: Enclosed in BEGIN ... ROLLBACK. Leaves zero test data behind.
-- SAFETY: NEVER RUN THIS SCRIPT AGAINST PRODUCTION SUPABASE.
-- ==============================================================================

BEGIN;

-- ------------------------------------------------------------------------------
-- 0. PRE-FLIGHT ENVIRONMENT & MOCK AUTH SETUP
-- ------------------------------------------------------------------------------
DO $$
BEGIN
    -- Environment Safeguard: Prohibit execution against production project
    IF current_database() LIKE '%vcisakapfzpqziwjyfni%' THEN
        RAISE EXCEPTION 'SAFETY HALT: Execution against production Supabase database is strictly prohibited!';
    END IF;

    -- Ensure auth schema exists for isolated local test environments
    CREATE SCHEMA IF NOT EXISTS auth;
    CREATE TABLE IF NOT EXISTS auth.users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email TEXT
    );
END $$;

-- Helper to safely create synthetic auth.users records adapting to any local mock schema
CREATE OR REPLACE FUNCTION pg_temp.create_mock_auth_user(p_id UUID, p_email TEXT)
RETURNS VOID AS $$
DECLARE
    v_has_email BOOLEAN;
    v_has_aud BOOLEAN;
    v_has_role BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'auth' AND table_name = 'users' AND column_name = 'email'
    ) INTO v_has_email;

    SELECT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'auth' AND table_name = 'users' AND column_name = 'aud'
    ) INTO v_has_aud;

    SELECT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'auth' AND table_name = 'users' AND column_name = 'role'
    ) INTO v_has_role;

    IF v_has_email AND v_has_aud AND v_has_role THEN
        EXECUTE 'INSERT INTO auth.users (id, email, aud, role) VALUES ($1, $2, ''authenticated'', ''authenticated'') ON CONFLICT (id) DO NOTHING'
        USING p_id, p_email;
    ELSIF v_has_email THEN
        EXECUTE 'INSERT INTO auth.users (id, email) VALUES ($1, $2) ON CONFLICT (id) DO NOTHING'
        USING p_id, p_email;
    ELSE
        EXECUTE 'INSERT INTO auth.users (id) VALUES ($1) ON CONFLICT (id) DO NOTHING'
        USING p_id;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Helper to switch context to role authenticated with a simulated auth.uid()
CREATE OR REPLACE FUNCTION pg_temp.set_test_auth_context(p_user_id UUID)
RETURNS VOID AS $$
BEGIN
    PERFORM set_config('request.jwt.claim.sub', p_user_id::text, true);
    PERFORM set_config('request.jwt.claim.role', 'authenticated', true);
    PERFORM set_config('request.jwt.claims', json_build_object('sub', p_user_id::text, 'role', 'authenticated')::text, true);
    PERFORM set_config('role', 'authenticated', true);
END;
$$ LANGUAGE plpgsql;

-- Helper to reset context back to postgres superuser
CREATE OR REPLACE FUNCTION pg_temp.reset_test_auth_context()
RETURNS VOID AS $$
BEGIN
    PERFORM set_config('role', 'postgres', true);
    PERFORM set_config('request.jwt.claim.sub', '', true);
    PERFORM set_config('request.jwt.claim.role', '', true);
    PERFORM set_config('request.jwt.claims', '', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ------------------------------------------------------------------------------
-- 1. SECURITY ASSERTION SUITE EXECUTION
-- ------------------------------------------------------------------------------
DO $$
DECLARE
    -- Synthetic User IDs
    v_admin_id UUID := '11111111-1111-4111-8111-111111111111'::UUID;
    v_unauth_manager_id UUID := '22222222-2222-4222-8222-222222222222'::UUID;
    v_auth_manager_id UUID := '33333333-3333-4333-8333-333333333333'::UUID;

    -- Test Entity IDs
    v_person_id UUID;
    v_dist_id UUID;
    v_order_id UUID;
    v_item_id UUID;
    v_entry1_id UUID;
    v_entry2_id UUID;
    v_entry3_id UUID;
    v_settle_id UUID;
    v_exp_owned_id UUID;
    v_exp_indep_id UUID;

    -- Verification Variables
    v_res JSONB;
    v_rec RECORD;
    v_rec_cnt INT;
    v_err_state TEXT;
    v_err_msg TEXT;
    v_test_passed BOOLEAN;
BEGIN
    RAISE NOTICE '====================================================================';
    RAISE NOTICE '  STARTING PHASE 2 v2.6 APPROVAL SECURITY TEST SUITE (STAGING/LOCAL)';
    RAISE NOTICE '====================================================================';

    -- STEP A: Provision Synthetic Authentication Users in auth.users
    PERFORM pg_temp.create_mock_auth_user(v_admin_id, 'superadmin@test.local');
    PERFORM pg_temp.create_mock_auth_user(v_unauth_manager_id, 'unauth_manager@test.local');
    PERFORM pg_temp.create_mock_auth_user(v_auth_manager_id, 'auth_manager@test.local');

    -- STEP B: Provision Profiles (Foreign key to auth.users is satisfied)
    INSERT INTO public.profiles (id, full_name, role, is_active)
    VALUES (v_admin_id, 'Test Super Admin', 'Super_Admin', true)
    ON CONFLICT (id) DO UPDATE SET role = 'Super_Admin', is_active = true;

    INSERT INTO public.profiles (id, full_name, role, is_active)
    VALUES (v_unauth_manager_id, 'Test Unauthorized Manager', 'Manager', true)
    ON CONFLICT (id) DO UPDATE SET role = 'Manager', is_active = true;

    INSERT INTO public.profiles (id, full_name, role, is_active)
    VALUES (v_auth_manager_id, 'Test Authorized Manager', 'Manager', true)
    ON CONFLICT (id) DO UPDATE SET role = 'Manager', is_active = true;

    -- STEP C: Configure User Permissions
    -- v_unauth_manager has NO approval permissions
    DELETE FROM public.user_permissions WHERE user_id IN (v_unauth_manager_id, v_auth_manager_id);
    INSERT INTO public.user_permissions (user_id, permission_id) VALUES
    (v_unauth_manager_id, 'payments.view'),
    (v_unauth_manager_id, 'payments.create'),
    (v_unauth_manager_id, 'settlement.view'),
    (v_unauth_manager_id, 'settlement.create');

    -- v_auth_manager has explicit approve permissions
    INSERT INTO public.user_permissions (user_id, permission_id) VALUES
    (v_auth_manager_id, 'payments.view'),
    (v_auth_manager_id, 'payments.create'),
    (v_auth_manager_id, 'payments.approve'),
    (v_auth_manager_id, 'settlement.view'),
    (v_auth_manager_id, 'settlement.create'),
    (v_auth_manager_id, 'settlement.approve');

    -- STEP D: Setup Domain Entities
    INSERT INTO public.persons (code, name, category, default_rate)
    VALUES ('TST-PER-01', 'Test Worker', 'Labourer', 50.00)
    RETURNING id INTO v_person_id;

    INSERT INTO public.distributors (code, name, is_active)
    VALUES ('TST-DIST-01', 'Test Distributor', true)
    RETURNING id INTO v_dist_id;

    -- --------------------------------------------------------------------------
    -- TEST 1: Direct INSERT Approved on Person Ledger (Must FAIL)
    -- --------------------------------------------------------------------------
    v_test_passed := false;
    BEGIN
        PERFORM pg_temp.set_test_auth_context(v_unauth_manager_id);
        
        INSERT INTO public.person_ledger_entries (
            reference_number, person_id, entry_type, direction,
            amount, description, status, created_by
        ) VALUES (
            'REF-ILLEGAL-01', v_person_id, 'Payment', 'Debit',
            5000.00, 'Direct approved insert attempt', 'Approved', v_unauth_manager_id
        );
        PERFORM pg_temp.reset_test_auth_context();
        RAISE EXCEPTION 'ASSERTION FAILURE: Direct INSERT with status Approved succeeded!';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT, v_err_state = RETURNED_SQLSTATE;
        PERFORM pg_temp.reset_test_auth_context();
        IF v_err_msg LIKE '%must start with status Pending%' THEN
            v_test_passed := true;
            RAISE NOTICE '[PASS] TEST 1: Direct INSERT Approved blocked by workflow trigger (Message: %)', v_err_msg;
        ELSE
            RAISE EXCEPTION 'TEST 1 FAILED: Rejected with unexpected error (State: %, Msg: %)', v_err_state, v_err_msg;
        END IF;
    END;

    -- Insert valid Pending entries for subsequent tests
    INSERT INTO public.person_ledger_entries (
        reference_number, person_id, entry_type, direction,
        amount, description, notes, status, created_by
    ) VALUES (
        'REF-TEST-PEND-01', v_person_id, 'Payment', 'Debit',
        1000.00, 'Legitimate pending payment', 'Test transaction note', 'Pending', v_unauth_manager_id
    ) RETURNING id INTO v_entry1_id;

    INSERT INTO public.person_ledger_entries (
        reference_number, person_id, entry_type, direction,
        amount, description, notes, status, created_by
    ) VALUES (
        'REF-TEST-PEND-02', v_person_id, 'Work_Earning', 'Payable',
        2500.00, 'Legitimate pending work earning', 'Work note', 'Pending', v_auth_manager_id
    ) RETURNING id INTO v_entry2_id;

    -- --------------------------------------------------------------------------
    -- TEST 2: Direct UPDATE of status via authenticated role (Must FAIL)
    -- --------------------------------------------------------------------------
    v_test_passed := false;
    BEGIN
        PERFORM pg_temp.set_test_auth_context(v_unauth_manager_id);

        -- Attempt direct column update on status
        UPDATE public.person_ledger_entries
        SET status = 'Approved'
        WHERE id = v_entry1_id;

        PERFORM pg_temp.reset_test_auth_context();
        RAISE EXCEPTION 'ASSERTION FAILURE: Direct UPDATE on status column was permitted!';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT, v_err_state = RETURNED_SQLSTATE;
        PERFORM pg_temp.reset_test_auth_context();
        
        -- Must fail with PostgreSQL column permission denied (SQLSTATE 42501)
        IF v_err_state = '42501' AND v_err_msg LIKE '%permission denied for column "status"%' THEN
            v_test_passed := true;
            RAISE NOTICE '[PASS] TEST 2: Direct UPDATE status blocked by PostgreSQL column privilege (SQLSTATE 42501)';
        ELSIF v_err_msg LIKE '%check constraint%' OR v_err_msg LIKE '%violates row-level security%' THEN
            v_test_passed := true;
            RAISE NOTICE '[PASS] TEST 2: Direct UPDATE status blocked by RLS / Constraint policy: %', v_err_msg;
        ELSE
            RAISE EXCEPTION 'TEST 2 FAILED: Rejected with unexpected error (State: %, Msg: %)', v_err_state, v_err_msg;
        END IF;
    END;

    -- --------------------------------------------------------------------------
    -- TEST 3: Unauthorized RPC Approval (Must FAIL with explicit Auth Error)
    -- --------------------------------------------------------------------------
    v_test_passed := false;
    BEGIN
        PERFORM pg_temp.set_test_auth_context(v_unauth_manager_id);

        PERFORM public.approve_person_ledger_entry(v_entry1_id);

        PERFORM pg_temp.reset_test_auth_context();
        RAISE EXCEPTION 'ASSERTION FAILURE: Unauthorized Manager was able to approve person ledger entry!';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT, v_err_state = RETURNED_SQLSTATE;
        PERFORM pg_temp.reset_test_auth_context();

        IF v_err_msg LIKE '%Unauthorized: Only Super_Admin or users with payments.approve%' THEN
            -- Verify record in database was NOT altered
            SELECT status INTO v_rec FROM public.person_ledger_entries WHERE id = v_entry1_id;
            IF v_rec.status = 'Pending' THEN
                v_test_passed := true;
                RAISE NOTICE '[PASS] TEST 3: Unauthorized RPC approval rejected and entry remained Pending (Msg: %)', v_err_msg;
            ELSE
                RAISE EXCEPTION 'TEST 3 FAILED: Error thrown but entry status changed to %', v_rec.status;
            END IF;
        ELSE
            RAISE EXCEPTION 'TEST 3 FAILED: Rejected with unexpected error (State: %, Msg: %)', v_err_state, v_err_msg;
        END IF;
    END;

    -- --------------------------------------------------------------------------
    -- TEST 4: Authorized RPC Approval by Super Admin (Must SUCCEED)
    -- --------------------------------------------------------------------------
    PERFORM pg_temp.set_test_auth_context(v_admin_id);
    v_res := public.approve_person_ledger_entry(v_entry1_id);
    PERFORM pg_temp.reset_test_auth_context();

    IF (v_res->>'success')::boolean = true AND v_res->>'status' = 'Approved' THEN
        SELECT status, approved_by, approved_at INTO v_rec FROM public.person_ledger_entries WHERE id = v_entry1_id;
        IF v_rec.status = 'Approved' AND v_rec.approved_by = v_admin_id AND v_rec.approved_at IS NOT NULL THEN
            RAISE NOTICE '[PASS] TEST 4: Authorized Super Admin approval succeeded and audit fields populated correctly';
        ELSE
            RAISE EXCEPTION 'TEST 4 FAILED: RPC returned success but row state is invalid: %', row_to_json(v_rec);
        END IF;
    ELSE
        RAISE EXCEPTION 'TEST 4 FAILED: RPC returned failure: %', v_res;
    END IF;

    -- --------------------------------------------------------------------------
    -- TEST 5: Authorized RPC Approval by Manager with Permission (Must SUCCEED)
    -- --------------------------------------------------------------------------
    PERFORM pg_temp.set_test_auth_context(v_auth_manager_id);
    v_res := public.approve_person_ledger_entry(v_entry2_id);
    PERFORM pg_temp.reset_test_auth_context();

    IF (v_res->>'success')::boolean = true AND v_res->>'status' = 'Approved' THEN
        SELECT status, approved_by, approved_at INTO v_rec FROM public.person_ledger_entries WHERE id = v_entry2_id;
        IF v_rec.status = 'Approved' AND v_rec.approved_by = v_auth_manager_id AND v_rec.approved_at IS NOT NULL THEN
            RAISE NOTICE '[PASS] TEST 5: Authorized Manager (with payments.approve) approval succeeded';
        ELSE
            RAISE EXCEPTION 'TEST 5 FAILED: Manager approved entry has invalid state: %', row_to_json(v_rec);
        END IF;
    ELSE
        RAISE EXCEPTION 'TEST 5 FAILED: Manager approval RPC failed: %', v_res;
    END IF;

    -- --------------------------------------------------------------------------
    -- TEST 6: Repeated Approval on already Approved record (Must FAIL)
    -- --------------------------------------------------------------------------
    v_test_passed := false;
    BEGIN
        PERFORM pg_temp.set_test_auth_context(v_admin_id);
        PERFORM public.approve_person_ledger_entry(v_entry1_id);
        PERFORM pg_temp.reset_test_auth_context();
        RAISE EXCEPTION 'ASSERTION FAILURE: Repeated approval was permitted on already Approved record!';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT, v_err_state = RETURNED_SQLSTATE;
        PERFORM pg_temp.reset_test_auth_context();

        IF v_err_msg LIKE '%is already Approved and cannot be approved%' THEN
            v_test_passed := true;
            RAISE NOTICE '[PASS] TEST 6: Repeated approval rejected as expected (Msg: %)', v_err_msg;
        ELSE
            RAISE EXCEPTION 'TEST 6 FAILED: Repeated approval threw unexpected error: %', v_err_msg;
        END IF;
    END;

    -- --------------------------------------------------------------------------
    -- TEST 7: Authorized Cancellation & Strict Expense Ownership Reversal
    -- --------------------------------------------------------------------------
    -- Create entry with 1 owned expense and 1 independent expense
    v_entry3_id := gen_random_uuid();
    v_exp_owned_id := gen_random_uuid();
    v_exp_indep_id := gen_random_uuid();

    -- Owned expense explicitly has originating_ledger_entry_id = v_entry3_id
    INSERT INTO public.expenses (
        id, reference_number, category, amount, status, 
        person_id, originating_ledger_entry_id, description
    ) VALUES (
        v_exp_owned_id, 'EXP-OWNED-01', 'Company', 3000.00, 'Approved',
        v_person_id, v_entry3_id, 'Expense owned by ledger entry'
    );

    -- Independent expense has originating_ledger_entry_id = NULL
    INSERT INTO public.expenses (
        id, reference_number, category, amount, status, 
        person_id, originating_ledger_entry_id, description
    ) VALUES (
        v_exp_indep_id, 'EXP-INDEP-01', 'Company', 1500.00, 'Approved',
        v_person_id, NULL, 'Independent operational expense'
    );

    INSERT INTO public.person_ledger_entries (
        id, reference_number, person_id, entry_type, direction,
        amount, description, expense_id, status, created_by
    ) VALUES (
        v_entry3_id, 'REF-TEST-EXP-01', v_person_id, 'Payment', 'Debit',
        3000.00, 'Payment linked to expense', v_exp_owned_id, 'Pending', v_admin_id
    );

    -- Approve entry
    PERFORM pg_temp.set_test_auth_context(v_admin_id);
    PERFORM public.approve_person_ledger_entry(v_entry3_id);

    -- Cancel entry
    v_res := public.cancel_person_ledger_entry(v_entry3_id, 'Testing strict expense ownership');
    PERFORM pg_temp.reset_test_auth_context();

    -- Verify:
    -- 1. Entry is Cancelled
    SELECT status, notes INTO v_rec FROM public.person_ledger_entries WHERE id = v_entry3_id;
    IF v_rec.status != 'Cancelled' OR v_rec.notes NOT LIKE '%Cancelled: Testing strict expense ownership%' THEN
        RAISE EXCEPTION 'TEST 7 FAILED: Entry status was not cancelled or notes not updated: %', row_to_json(v_rec);
    END IF;

    -- 2. Owned expense is Cancelled
    SELECT status INTO v_rec FROM public.expenses WHERE id = v_exp_owned_id;
    IF v_rec.status != 'Cancelled' THEN
        RAISE EXCEPTION 'TEST 7 FAILED: Owned expense was not automatically cancelled!';
    END IF;

    -- 3. Independent expense remains Approved
    SELECT status INTO v_rec FROM public.expenses WHERE id = v_exp_indep_id;
    IF v_rec.status != 'Approved' THEN
        RAISE EXCEPTION 'TEST 7 FAILED: Independent expense was wrongly cancelled (status: %)!', v_rec.status;
    END IF;

    RAISE NOTICE '[PASS] TEST 7: Authorized cancellation reversed owned expense and protected independent expense';

    -- --------------------------------------------------------------------------
    -- TEST 8: Cancelled Record Immutability (Cannot re-approve or modify)
    -- --------------------------------------------------------------------------
    v_test_passed := false;
    BEGIN
        PERFORM pg_temp.set_test_auth_context(v_admin_id);
        PERFORM public.approve_person_ledger_entry(v_entry3_id);
        PERFORM pg_temp.reset_test_auth_context();
        RAISE EXCEPTION 'ASSERTION FAILURE: Re-approval of Cancelled entry succeeded!';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT, v_err_state = RETURNED_SQLSTATE;
        PERFORM pg_temp.reset_test_auth_context();

        IF v_err_msg LIKE '%is already Cancelled and cannot be approved%' THEN
            v_test_passed := true;
            RAISE NOTICE '[PASS] TEST 8: Reopening Cancelled entry blocked as expected (Msg: %)', v_err_msg;
        ELSE
            RAISE EXCEPTION 'TEST 8 FAILED: Re-approval on Cancelled threw unexpected error: %', v_err_msg;
        END IF;
    END;

    -- --------------------------------------------------------------------------
    -- TEST 9: Distributor Settlement Direct UPDATE recovery_id (Must FAIL)
    -- --------------------------------------------------------------------------
    INSERT INTO public.distributor_settlements (
        reference_number, distributor_id, settlement_type,
        amount, status, created_by
    ) VALUES (
        'SET-TEST-001', v_dist_id, 'Commission_Cash_Paid',
        500.00, 'Pending', v_unauth_manager_id
    ) RETURNING id INTO v_settle_id;

    v_test_passed := false;
    BEGIN
        PERFORM pg_temp.set_test_auth_context(v_unauth_manager_id);
        
        -- Attempt direct column update on recovery_id
        UPDATE public.distributor_settlements
        SET recovery_id = gen_random_uuid()
        WHERE id = v_settle_id;

        PERFORM pg_temp.reset_test_auth_context();
        RAISE EXCEPTION 'ASSERTION FAILURE: Direct UPDATE on recovery_id was permitted!';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT, v_err_state = RETURNED_SQLSTATE;
        PERFORM pg_temp.reset_test_auth_context();

        IF v_err_state = '42501' AND v_err_msg LIKE '%permission denied for column "recovery_id"%' THEN
            v_test_passed := true;
            RAISE NOTICE '[PASS] TEST 9: Direct UPDATE recovery_id blocked by column privilege (SQLSTATE 42501)';
        ELSIF v_err_msg LIKE '%check constraint%' OR v_err_msg LIKE '%violates row-level security%' THEN
            v_test_passed := true;
            RAISE NOTICE '[PASS] TEST 9: Direct UPDATE recovery_id blocked: %', v_err_msg;
        ELSE
            RAISE EXCEPTION 'TEST 9 FAILED: Rejected with unexpected error (State: %, Msg: %)', v_err_state, v_err_msg;
        END IF;
    END;

    RAISE NOTICE '====================================================================';
    RAISE NOTICE '  ALL 9 SECURITY & ACCOUNTING ASSERTIONS PASSED WITH EXACT CHECKS!   ';
    RAISE NOTICE '====================================================================';
END $$;

-- ------------------------------------------------------------------------------
-- 2. MANDATORY CLEANUP: AUTOMATIC ROLLBACK (LEAVES ZERO DIRTY STATE)
-- ------------------------------------------------------------------------------
ROLLBACK;
